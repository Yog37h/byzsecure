#!/usr/bin/env python3
"""
Quick start script for Google Colab
Run this after uploading to Colab
"""

# Install packages
import subprocess
import sys

packages = ["medmnist", "psutil", "GPUtil"]
for package in packages:
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Check GPU
import torch
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name()}")

# Run debug
import os
os.system("python main.py --debug --global_ep 2")
